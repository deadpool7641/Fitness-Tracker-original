from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# User model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return redirect(url_for('register'))

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration Successful!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')

# Dashboard (Workout Plans) route
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user)

# Workout Plans route
@app.route('/workout_plans')
@login_required
def workout_plans():
    return render_template('workout_plans.html')

# Weight Loss Plan route
@app.route('/weight_loss_plan')
@login_required
def weight_loss_plan():
    weight_loss_workouts = [
        {"day": "Day 1", "workout": "30 minutes jogging, 20 squats, 20 push-ups"},
        {"day": "Day 2", "workout": "15 minutes cycling, 15 lunges, 15 burpees"},
        {"day": "Day 3", "workout": "Rest day"},
        {"day": "Day 4", "workout": "20 minutes swimming, 30 jumping jacks"},
        {"day": "Day 5", "workout": "40 minutes walking, 10 squats, 10 push-ups"},
    ]
    return render_template('weight_loss_plan.html', workouts=weight_loss_workouts)

# Weight Gain Plan route
@app.route('/weight_gain_plan')
@login_required
def weight_gain_plan():
    weight_gain_workouts = [
        {"day": "Day 1", "workout": "Chest press, Squats, Deadlifts, 10-12 reps x 3 sets"},
        {"day": "Day 2", "workout": "Pull-ups, Bench press, Overhead press, 10-12 reps x 3 sets"},
        {"day": "Day 3", "workout": "Rest day"},
        {"day": "Day 4", "workout": "Leg press, Lunges, Bicep curls, 10-12 reps x 3 sets"},
        {"day": "Day 5", "workout": "Deadlifts, Rows, Push-ups, 10-12 reps x 3 sets"},
    ]
    return render_template('weight_gain_plan.html', workouts=weight_gain_workouts)

# Logout route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

# Database initialization and app run
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # This will create the tables for all models
    app.run(debug=True)
