document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('h1').classList.add('fade-in');
});

document.querySelectorAll('button').forEach(button => {
    button.addEventListener('mouseover', () => {
        button.style.backgroundColor = '#555';
    });
    button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '#28a745';
    });
});
